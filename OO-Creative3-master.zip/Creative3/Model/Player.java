package Model;

public class Player {

	private HandSign sign;

	public void setSign(HandSign sign){
		this.sign = sign;
	}

	public HandSign getSign(){
		return sign;
	}
	
}
