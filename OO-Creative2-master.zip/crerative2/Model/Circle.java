package Model;

import java.awt.Graphics2D;

public class Circle {

	public void render(Graphics2D g2){
		g2.drawOval(325, 100, 50, 50);
	} 
	
}
