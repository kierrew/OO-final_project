package Model.StrategyPattern;

public interface BulletAnimateStrategy {

	void animateAlgorithim();
	
}
