package Model.StrategyPattern;

public interface SnakeMoveStrategy {
	
	void moveAlgorithm();

}
