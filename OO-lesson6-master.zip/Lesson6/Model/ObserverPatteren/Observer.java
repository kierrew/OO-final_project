package Model.ObserverPatteren;

public interface Observer {

	void snakeAtefood();
	void snakeAtePoision();
	void snakeLeftScene();
	void snakeSelfCollision();
	
}
